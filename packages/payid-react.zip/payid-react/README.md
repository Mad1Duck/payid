# payid-react

React hooks untuk PAY.ID — mirip ENS hooks tapi untuk payment policies.

## Install

```bash
bun add payid-react wagmi viem
```

## Setup

Wrap app dengan `PayIDProvider` setelah `WagmiProvider`:

```tsx
import { WagmiProvider } from 'wagmi'
import { PayIDProvider } from 'payid-react'

function App() {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <PayIDProvider>
          <YourApp />
        </PayIDProvider>
      </QueryClientProvider>
    </WagmiProvider>
  )
}
```

Dengan custom addresses (setelah deploy ke chain baru):

```tsx
<PayIDProvider
  contracts={{
    4202: {
      ruleAuthority:       '0xABC...',
      ruleItemERC721:      '0xDEF...',
      combinedRuleStorage: '0x123...',
      payIDVerifier:       '0x456...',
      payWithPayID:        '0x789...',
    }
  }}
>
```

---

## Hooks

### Rules

```tsx
// Semua rules yang pernah dibuat
const { data: rules, isLoading } = useRules()
const { data: activeRules }      = useRules({ onlyActive: true })
const { data: myRules }          = useRules({ creator: '0x...' })

// Shortcut — rules milik wallet yang connect
const { data: myRules } = useMyRules()

// Single rule
const { data: rule } = useRule(1n)

// Subscription
const { data: sub } = useSubscription(address)
// sub.isActive, sub.expiry, sub.maxSlots, sub.logicalRuleCount
```

### Combined Rules

```tsx
// Semua combined rules di CombinedRuleStorage
const { data: allRules } = useAllCombinedRules()
const { data: active }   = useAllCombinedRules({ onlyActive: true })

// Active rule milik address
const { data: rule } = useActiveCombinedRule(address)

// Per direction (INBOUND / OUTBOUND)
const { data: inbound }  = useActiveCombinedRuleByDirection(address, RuleDirection.INBOUND)
const { data: outbound } = useActiveCombinedRuleByDirection(address, RuleDirection.OUTBOUND)

// Rule sets dari RuleAuthority
const { data: ruleSets } = useOwnerRuleSets(address)
const { data: mine }     = useMyRuleSets()
```

### Payment

```tsx
// Pay ETH
const { pay, isPending, isSuccess } = usePayETH()
pay({ decision, signature, attestationUIDs: [] })

// Pay ERC20 (approve dulu)
const { pay, isPending, isSuccess } = usePayERC20()
pay({ decision, signature })

// Verify proof (view)
const { data: isValid } = useVerifyDecision(decision, signature)

// Cek nonce sudah dipakai
const { data: used } = useNonceUsed(payer, nonce)
```

---

## Contoh lengkap

```tsx
import {
  useMyRules,
  useAllCombinedRules,
  useSubscription,
  RuleDirection,
} from 'payid-react'
import { useAccount } from 'wagmi'

export function RulesDashboard() {
  const { address } = useAccount()
  const { data: rules, isLoading }   = useMyRules()
  const { data: combined }           = useAllCombinedRules({ onlyActive: true })
  const { data: sub }                = useSubscription(address)

  if (isLoading) return <div>Loading...</div>

  return (
    <div>
      <h2>Subscription</h2>
      <p>{sub?.isActive ? '✅ Active' : '❌ Inactive'}</p>
      <p>Slots: {sub?.logicalRuleCount}/{sub?.maxSlots}</p>

      <h2>My Rules ({rules.length})</h2>
      {rules.map(rule => (
        <div key={rule.ruleId.toString()}>
          <span>{rule.uri}</span>
          <span>{rule.active ? '🟢' : '🔴'}</span>
          <span>v{rule.version}</span>
        </div>
      ))}

      <h2>Active Combined Rules ({combined.length})</h2>
      {combined.map(rule => (
        <div key={rule.hash}>
          <span>{rule.hash.slice(0, 10)}...</span>
          <span>{rule.ruleRefs.length} refs</span>
        </div>
      ))}
    </div>
  )
}
```
